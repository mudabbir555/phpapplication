<script>
  function editRow(button) {
    var row = button.parentNode.parentNode;
    var cells = row.getElementsByTagName("td");

    // Get the values from the row cells
    var name = cells[0].innerText;
    var idNumber = cells[1].innerText;
    var phone = cells[2].innerText;
    // Retrieve other cell values as needed

    // Perform desired edit operations, such as updating a form with the values
    console.log("Editing row: " + name + " - " + idNumber + " - " + phone);
  }

  function deleteRow(button) {
    var row = button.parentNode.parentNode;
    row.remove();
  }
</script>