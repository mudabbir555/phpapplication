<?php
include_once "dbconn.php";

// Function to display the image
function displayImage($imageData) {
    $base64Data = base64_encode($imageData);
    $imageSrc = 'data:image/jpeg;base64,' . $base64Data;
    echo '<img src="' . $imageSrc . '" alt="Image">';
}

// Check if the form is submitted
if (isset($_POST['upload'])) {
    // Retrieve form input values
    $vehicle = $_POST["vehicle"];
    $title = $_POST["title"];
    $description = $_POST["description"];
    $priority = $_POST["priority"];
    $fileData = $_FILES["file"]["tmp_name"];
    $assigned = $_POST["assigned"];

    // Establish database connection
    // $conn = mysqli_connect('localhost', 'username', 'password', 'database');

    // Check if the connection is successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Read the image file
    $imageData = file_get_contents($fileData);

    // Escape the image data to prevent SQL injection
    $escapedImageData = mysqli_real_escape_string($conn, $imageData);

    // Prepare the SQL statement
    $query = "INSERT INTO add_issue (vehicle, title, description, priority, file, assigned) VALUES ('$vehicle', '$title', '$description', '$priority', '$escapedImageData', '$assigned')";

    // Execute the statement
    $query_run = mysqli_query($conn, $query);

    // Check if the query executed successfully
    if ($query_run) {
        echo "Form data and image successfully inserted into the database.";
    } else {
        echo "Error inserting form data and image into the database.";
    }

    // Close the database connection
    mysqli_close($conn);
}

?>
