<?php
include_once "dbconn.php";

// Check if the form is submitted
if (isset($_POST['upload'])) {
    // Retrieve form input values
    $Name = $_POST["Name"];
    $User_name = $_POST["User_name"];
    $email = $_POST["email"];
    $Phone = $_POST["Phone"];
    $address = $_POST["address"];

    // Establish database connection
    // $conn = mysqli_connect('localhost', 'username', 'password', 'database');

    // Check if the connection is successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare the SQL statement
    $query = "INSERT INTO add_user (Name, User_name, email, Phone, address) VALUES ('$Name', '$User_name', '$email', '$Phone', '$address')";

    // Execute the statement
    $query_run = mysqli_query($conn, $query);

    // Check if the query executed successfully
    if ($query_run) {
        echo "Form data successfully inserted into the database.";
    } else {
        echo "Error inserting form data into the database.";
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
