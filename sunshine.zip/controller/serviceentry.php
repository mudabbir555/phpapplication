<?php
include_once "dbconn.php";

// Check if the form is submitted
if (isset($_POST['upload'])) {
    // Retrieve form input values
    $Vehicle = $_POST["Vehicle"];
    $Serviced = $_POST["Serviced"];
    $Odometer =  $_POST["Odometer"];
    $CompletedS = $_POST["CompletedS"];
    $Vendor = $_POST["Vendor"];
    $Comments = $_POST["Comments"];
    $Labour =  $_POST["Labour"];
    $Parts = $_POST["Parts"];
    $Tax =  $_POST["Tax"];
    $InvoiceN =  $_POST["InvoiceN"];

    // Rest of the code...
}

    // $conn = mysqli_connect('localhost', 'username', 'password', 'database');

    // Check if the connection is successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare the SQL statement
    $query = "INSERT INTO service_entry (Vehicle, Serviced, Odometer, CompletedS, Vendor, Comments, Labour, Parts, Tax, InvoiceN) VALUES ('$Vehicle', '$Serviced', '$Odometer', '$CompletedS', '$Vendor', '$Comments', '$Labour', '$Parts', '$Tax', '$InvoiceN')";

    // Execute the statement
    $query_run = mysqli_query($conn, $query);

    // Check if the query executed successfully
    if ($query_run) {
        echo "Form data successfully inserted into the database.";
    } else {
        echo "Error inserting form data into the database.";
    }

    // Close the database connection
    mysqli_close($conn);

?>
