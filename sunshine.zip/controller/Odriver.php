<?php
include_once "dbconn.php";
function displayImage($imageData) {
    $base64Data = base64_encode($imageData);
    $imageSrc = 'data:image/jpeg;base64,' . $base64Data;
    echo '<img src="' . $imageSrc . '" alt="Image">';
}
// Check if the form is submitted
if (isset($_POST['upload'])) {
    // Retrieve form input values
    $Name = $_POST["Name"];
    $id_Number = $_POST["id_Number"];
    $Phone = $_POST["Phone"];
    $Present_address = $_POST["Present_address"];
    $Permanent_address = $_POST["Permanent_address"];
    $fileData = $_FILES["image"]["tmp_name"];

    // Establish database connection
// Check if an image file is uploaded
if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    // Retrieve file details
    $file = $_FILES['image'];
    $fileTmp = $file['tmp_name'];

    // Read the image file
    $imageData = file_get_contents($fileTmp);

    // Escape the image data to prevent SQL injection
    $escapedImageData = mysqli_real_escape_string($conn, $imageData);

    // Prepare the SQL statement
    $query = "INSERT INTO o_driver (Name, id_Number, Phone, Present_address, Permanent_address, image) VALUES ('$Name', '$id_Number', '$Phone', '$Present_address', '$Permanent_address', '$escapedImageData')";

    // Execute the statement
    $query_run = mysqli_query($conn, $query);

    // Check if the query executed successfully
    if ($query_run) {
        echo "Form data successfully inserted into the database.";
    } else {
        echo "Error inserting form data into the database: " . mysqli_error($conn);
    }
} else {
    echo "No image file uploaded or an error occurred during upload.";
}
}

?>
