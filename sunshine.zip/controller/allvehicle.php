<?php
include_once "dbconn.php";

function displayImage($imageData)
{
    $base64Data = base64_encode($imageData);
    $imageSrc = 'data:image/jpeg;base64,' . $base64Data;
    echo '<img src="' . $imageSrc . '" alt="Image">';
}

// Check if the form is submitted
if (isset($_POST['upload'])) {
    // Retrieve form input values
    $vehicleName = $_POST["vehicleName"];
    $vehicleNumber = $_POST["vehicleNumber"];
    $engineNumber = $_POST["engineNumber"];
    $model = $_POST["model"];
    $chassisNumber = $_POST["chassisNumber"];
    $yearOfManufacture = $_POST["yearOfManufacture"];
    $color = $_POST["color"];
    $fuelType = $_POST["fuelType"];
    $fuelMeasurement = $_POST["fuelMeasurement"];
    $trackUsage = $_POST["trackUsage"];
    $vehicleGroup = $_POST["vehicleGroup"];
    $secondaryMeter = isset($_POST["secondaryMeter"]) ? $_POST["secondaryMeter"] : '';

    if (isset($_FILES['vehicleImage']) && $_FILES['vehicleImage']['error'] === UPLOAD_ERR_OK) {
        // Retrieve file details
        $file = $_FILES['vehicleImage'];
        $fileTmp = $file['tmp_name'];

        // Read the image file
        $imageData = file_get_contents($fileTmp);

        // Escape the image data to prevent SQL injection
        $escapedImageData = mysqli_real_escape_string($conn, $imageData);

        // Prepare the SQL statement
        $query = "INSERT INTO add_vehicle (vehicleName, vehicleNumber, engineNumber, model, chassisNumber, yearOfManufacture, color, fuelType, fuelMeasurement, trackUsage, vehicleGroup, secondaryMeter, vehicleImage) 
        VALUES ('$vehicleName', '$vehicleNumber', '$engineNumber', '$model', '$chassisNumber', '$yearOfManufacture', '$color', '$fuelType', '$fuelMeasurement', '$trackUsage', '$vehicleGroup', '$secondaryMeter', '$escapedImageData')";

        // Execute the statement
        $query_run = mysqli_query($conn, $query);

        // Check if the query executed successfully
        if ($query_run) {
            echo "Form data successfully inserted into the database.";
        } else {
            echo "Error inserting form data into the database: " . mysqli_error($conn);
        }
    } else {
        echo "No image file uploaded or an error occurred during upload.";
    }
}
if (isset($_POST['id'])) {
    $id = $_POST['id'];

    // Delete the row from the database
    $query = "DELETE FROM add_vehicle WHERE id = '$id'";
    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "Row deleted successfully";
    } else {
        echo "Failed to delete the row";
    }

    // Close database connection
    mysqli_close($conn);
}
?>