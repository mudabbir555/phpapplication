<?php
include_once "dbconn.php";

function displayImage($imageData)
{
    $base64Data = base64_encode($imageData);
    $imageSrc = 'data:image/jpeg;base64,' . $base64Data;
    echo '<img src="' . $imageSrc . '" alt="Image">';
}

// Check if the form is submitted
if (isset($_POST['upload'])) {
    // Retrieve form input values
    $vehicleRc = $_POST["vehicleRc"];
    $vehiclePermit = $_POST["vehiclePermit"];
    $vehicleFitness = $_POST["vehicleFitness"];
    $vehicleInsurance = $_POST["vehicleInsurance"];
    $vehiclePUC = $_POST["vehiclePUC"];
    $policeVerificationSticker = $_POST["policeVerificationSticker"];
    $fileDataVRc = $_FILES["VRc"]["tmp_name"];
    $fileDataVpermit = $_FILES["Vpermit"]["tmp_name"];
    $fileDataVfitness = $_FILES["Vfitness"]["tmp_name"];
    $fileDataVinsurance = $_FILES["Vinsurance"]["tmp_name"];
    $fileDataVpuc = $_FILES["Vpuc"]["tmp_name"];
    $fileDataVpvs = $_FILES["Vpvs"]["tmp_name"];

    // Check if the connection is successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Read the file data
    $VRcData = file_get_contents($fileDataVRc);
    $VpermitData = file_get_contents($fileDataVpermit);
    $VfitnessData = file_get_contents($fileDataVfitness);
    $VinsuranceData = file_get_contents($fileDataVinsurance);
    $VpucData = file_get_contents($fileDataVpuc);
    $VpvsData = file_get_contents($fileDataVpvs);

    // Escape the file data to prevent SQL injection
    $escapedVRcData = mysqli_real_escape_string($conn, $VRcData);
    $escapedVpermitData = mysqli_real_escape_string($conn, $VpermitData);
    $escapedVfitnessData = mysqli_real_escape_string($conn, $VfitnessData);
    $escapedVinsuranceData = mysqli_real_escape_string($conn, $VinsuranceData);
    $escapedVpucData = mysqli_real_escape_string($conn, $VpucData);
    $escapedVpvsData = mysqli_real_escape_string($conn, $VpvsData);

    // Prepare the SQL statement
    $query = "INSERT INTO o_vehicle (vehicleRc, vehiclePermit, vehicleFitness, vehicleInsurance, vehiclePUC, policeVerificationSticker, VRc, Vpermit, Vfitness, Vinsurance, Vpuc, Vpvs) VALUES ('$vehicleRc', '$vehiclePermit', '$vehicleFitness', '$vehicleInsurance', '$vehiclePUC', '$policeVerificationSticker', '$escapedVRcData', '$escapedVpermitData', '$escapedVfitnessData', '$escapedVinsuranceData', '$escapedVpucData', '$escapedVpvsData')";

    // Execute the statement
    $query_run = mysqli_query($conn, $query);

    // Check if the query executed successfully
    if ($query_run) {
        echo "Form data successfully inserted into the database.";
    } else {
        echo "Error inserting form data into the database: " . mysqli_error($conn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
