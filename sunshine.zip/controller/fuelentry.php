<?php
include_once "dbconn.php";
function displayImage($imageData)
{
    $base64Data = base64_encode($imageData);
    $imageSrc = 'data:image/jpeg;base64,' . $base64Data;
    echo '<img src="' . $imageSrc . '" alt="Image">';
}
// Check if the form is submitted
if (isset($_POST['upload'])) {
    // Retrieve form input values
    $Vehicle = $_POST["Vehicle"];
    $Date = $_POST["Date"];
    $Odometer = $_POST["Odometer"];
    $Fuel_entry = isset($_POST["Fuel_entry"]) ? $_POST["Fuel_entry"] : ""; // Check if the key is present
    $Price = $_POST["Price"];
    $Vendor = $_POST["Vendor"];
    $Invoice = isset($_POST["Invoice"]) ? $_POST["Invoice"] : "";

    // Establish database connection
    if (isset($_FILES['Invoice']) && $_FILES['Invoice']['error'] === UPLOAD_ERR_OK) {
        // Retrieve file details
        $file = $_FILES['Invoice'];
        $fileTmp = $file['tmp_name'];
    
        // Read the image file
        $imageData = file_get_contents($fileTmp);
    
        // Escape the image data to prevent SQL injection
        $escapedImageData = mysqli_real_escape_string($conn, $imageData);
    
        // Prepare the SQL statement
        $query = "INSERT INTO fuel (Vehicle, Date, Odometer, Fuel_entry, Price, Vendor, Invoice) 
        VALUES ('$Vehicle', '$Date', '$Odometer', '$Fuel_entry', '$Price', '$Vendor', '$escapedImageData')";

        // Execute the statement
        $query_run = mysqli_query($conn, $query);
    
        // Check if the query executed successfully
        if ($query_run) {
            echo "Form data successfully inserted into the database.";
        } else {
            echo "Error inserting form data into the database: " . mysqli_error($conn);
        }
    } else {
        echo "No image file uploaded or an error occurred during upload.";
    }
    }
?>
