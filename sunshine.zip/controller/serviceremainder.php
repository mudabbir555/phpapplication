<?php
include_once "dbconn.php";

// Check if the form is submitted
if (isset($_POST['upload'])) {
    // Retrieve form input values
    $vehicleRc = $_POST["vehicleRc"];
    $vehiclePermit = $_POST["vehiclePermit"];
    $vehicleFitness = $_POST["vehicleFitness"];
    $vehicleInsurance = $_POST["vehicleInsurance"];
    $vehiclePUC = $_POST["vehiclePUC"];
    $policeVerificationSticker = $_POST["policeVerificationSticker"];

    // Establish database connection
    // $conn = mysqli_connect('localhost', 'username', 'password', 'database');

    // Check if the connection is successful
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Prepare the SQL statement
    $query = "INSERT INTO service_remainder (vehicleRc, vehiclePermit, vehicleFitness, vehicleInsurance, vehiclePUC, policeVerificationSticker) VALUES ('$vehicleRc', '$vehiclePermit', '$vehicleFitness', '$vehicleInsurance', '$vehiclePUC', '$policeVerificationSticker')";

    // Execute the statement
    $query_run = mysqli_query($conn, $query);

    // Check if the query executed successfully
    if ($query_run) {
        echo "Form data successfully inserted into the database.";
    } else {
        echo "Error inserting form data into the database.";
    }

    // Close the database connection
    mysqli_close($conn);
}
?>
