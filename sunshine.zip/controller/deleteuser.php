<?php
    include_once "dbconn.php";

    if (isset($_POST['id'])) {
        $id = $_POST['id'];

        // Delete the row from the database
        $query = "DELETE FROM add_user WHERE id = '$id'";
        $result = mysqli_query($conn, $query);

        if ($result) {
            echo "Row deleted successfully";
        } else {
            echo "Failed to delete the row";
        }

        // Close database connection
        mysqli_close($conn);
    }
?>
