<div class="overlay toggle-btn-mobile"></div>
<div class="footer">
			<p class="mb-0">Sunshine @2023 | Developed By : <a href="https://www.dodail.com/" target="_blank">Dodail solutions pvt ltd</a>
			</p>
		</div>
	</div>
	<!-- end wrapper -->
	<!--start switcher-->
	
	<!-- JavaScript -->
	<!-- Bootstrap JS -->
	<script src="assets/js/bootstrap.bundle.min.js"></script>
	
	<!--plugins-->
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/plugins/simplebar/js/simplebar.min.js"></script>
	<script src="assets/plugins/metismenu/js/metisMenu.min.js"></script>
	<script src="assets/plugins/perfect-scrollbar/js/perfect-scrollbar.js"></script>
	<!-- App JS -->
	<script src="assets/js/app.js"></script>
</body>

</html>